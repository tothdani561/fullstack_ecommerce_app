-- AlterTable
ALTER TABLE `users` MODIFY `lastname` VARCHAR(191) NULL,
    MODIFY `firstname` VARCHAR(191) NULL;
