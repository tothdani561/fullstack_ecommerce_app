import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import * as express from 'express';
import { join } from 'path';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // Statikus fájlok kiszolgálása a serve-static csomaggal
  app.use('/uploads', express.static(join(__dirname, '..', 'uploads')));

  app.useGlobalPipes(
    new ValidationPipe({
      transform: true, // Ez szükséges a @Transform működéséhez
      whitelist: true, // Nem várt mezők eltávolítása
      forbidNonWhitelisted: true, // Hiba dobása, ha nem várt mező érkezik
    }),
  );

  app.enableCors({
    origin: 'http://localhost:5173',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
  });


  await app.listen(3333);
}
bootstrap();
