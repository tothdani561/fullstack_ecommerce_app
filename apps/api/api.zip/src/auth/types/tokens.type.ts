export type Tokens = {
    accessToken: string;
    refreshToken: string;
}